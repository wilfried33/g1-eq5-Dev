```
    src             code source
    |   app.js      entry point
    |---config      environment variables
    |---models      database models
    |---routes      application routes
    |---services    business logic
    |---views       application front
    tests           tests
        |---unit    unit tests
        |---e2e     e2e tests
```
