/*
res.render('backlog', {projectId: id du projet, projectName: nom du projet, backlog: le backlog du project sélecioner avec toutes les us et les sprints})
res.render('addUserStory', {projectId: id du projet, projectName: nom du projet});
*/